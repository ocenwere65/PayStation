/**
 * Implementation of the pay station.
 *
 * Responsibilities:
 *
 * 1) Accept payment; 
 * 2) Calculate parking time based on payment; 
 * 3) Know earning, parking time bought; 
 * 4) Issue receipts; 
 * 5) Handle buy and cancel events.
 *
 * This source code is from the book "Flexible, Reliable Software: Using
 * Patterns and Agile Development" published 2010 by CRC Press. Author: Henrik B
 * Christensen Computer Science Department Aarhus University
 *
 * This source code is provided WITHOUT ANY WARRANTY either expressed or
 * implied. You may study, use, modify, and distribute it for non-commercial
 * purposes. For any commercial use, see http://www.baerbak.com/
 */

package edu.temple.cis.paystation;

import java.util.HashMap;
import java.util.Map;

public class PayStationImpl implements PayStation {
    
    private int insertedSoFar;
    private int timeBought;
    private Map<Integer, Integer> coin_map = new HashMap<Integer, Integer>();
    private int n = 0, d = 0, q = 0;
    

    @Override
    public void addPayment(int coinValue)
            throws IllegalCoinException {
        switch (coinValue) {
            case 5: 
                n++;
                coin_map.put(coinValue, n);
                break;
            case 10: 
                d++; 
                coin_map.put(coinValue, d);
                break;
            case 25: 
                q++; 
                coin_map.put(coinValue, q);
                break;
            default:
                throw new IllegalCoinException("Invalid coin: " + coinValue);
        }
        //coin_map.put(coinValue, 1);
        insertedSoFar += coinValue;
        timeBought = insertedSoFar / 5 * 2;
    }

    @Override
    public int readDisplay() {
        return timeBought;
    }

    @Override
    public Receipt buy() {
        Receipt r = new ReceiptImpl(timeBought);
        coin_map.clear();
        reset();
        return r;
    }

    @Override
    public Map<Integer, Integer> cancel() {
        coin_map.clear();
        reset();
        return coin_map;
    }
    
    private void reset() {
        timeBought = insertedSoFar = 0;
    }
    
    public int empty(){
        int moneyCollected;
        moneyCollected = insertedSoFar;
        reset();
        return moneyCollected;
    }
    
    public Map<Integer, Integer> mapReturn() {
        return coin_map;
    }
}
